﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ShoppingSpree
{
    public static  class ExceptionMessages
    {
        public const string EMPTY_NAME_EXCEPTION = "Name cannot be empty";
        public const string NEGATIVE_MONEY_EXCEPTION = "Money cannot be negative";
    }
}
