﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassBoxData
{
    public static class ExceptionMessages
    {
        public const string CANNOT_BE_LESS_THEN_ZERO_EXCEPTION = "{0} cannot be zero or negative.";
    }
}
