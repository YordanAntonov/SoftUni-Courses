﻿using System;

namespace RepairShop
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            
        }
    }
}
