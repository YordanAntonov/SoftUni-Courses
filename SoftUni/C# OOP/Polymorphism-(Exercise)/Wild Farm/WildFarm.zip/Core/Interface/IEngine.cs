﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Core.Interface
{
    public interface IEngine
    {
        void Run();
    }
}
