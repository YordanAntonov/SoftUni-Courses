﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Exceptions
{
    public class ExceptionMessages
    {
        public const string FoodNotEaten = "{0} does not eat {1}!";
    }
}
