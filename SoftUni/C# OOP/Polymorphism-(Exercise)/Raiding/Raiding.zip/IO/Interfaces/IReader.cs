﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Raiding.IO.Interfaces
{
    public interface IReader
    {
        string ReadLine();
    }
}
