﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicle.IO.Interfaces
{
    public interface IReader
    {
        string ReadLine();
    }
}
