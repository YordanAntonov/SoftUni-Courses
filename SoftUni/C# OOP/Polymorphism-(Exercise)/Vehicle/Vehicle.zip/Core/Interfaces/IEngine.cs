﻿
namespace Vehicle.Core.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}
