﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Military_Elite.Models.Enums
{
    public enum Corps
    {
        Airforces = 0,
        Marines = 1,
    }
}
