﻿using Military_Elite.Core;
using Military_Elite.Core.Interfaces;
using Military_Elite.IO;
using Military_Elite.IO.Interfaces;
using Military_Elite.Models;
using Military_Elite.Models.Contracts;
using Military_Elite.Models.Enums;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;

namespace Military_Elite
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            IReader reader = new ConsoleReader();
            IWriter write = new ConsoleWriter();

            IEngine engine = new Engine(reader, write);
            engine.Run();
        }

    }
}
