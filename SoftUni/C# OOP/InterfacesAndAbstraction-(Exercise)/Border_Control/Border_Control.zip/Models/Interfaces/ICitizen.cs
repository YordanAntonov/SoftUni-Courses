﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Border_Control.Models.Interfaces
{
    public interface ICitizen
    {
        public string NameOrModel { get; }
        public string Id { get; }
    }
}
