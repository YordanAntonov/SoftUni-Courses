﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Border_Control.Models.Interfaces
{
    public interface IBirthdate
    {
        public string Birthdate { get; }
    }
}
