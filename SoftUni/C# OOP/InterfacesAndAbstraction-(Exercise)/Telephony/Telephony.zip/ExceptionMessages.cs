﻿namespace Telephony
{
    public class ExceptionMessages
    {
        public const string INVALID_NUMBER = "Invalid number!";
        public const string INVALID_URL = "Invalid URL!";
    }
}
