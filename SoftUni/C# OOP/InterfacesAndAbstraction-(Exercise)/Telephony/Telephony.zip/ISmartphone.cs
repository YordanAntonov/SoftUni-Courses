﻿namespace Telephony
{
    public interface ISmartphone : IStationaryphone
    {
        string Browse(string value);
    }
}
