﻿namespace Footballers.Data
{
    public class EntityLengths
    {
        public const int FootballerNameMaxLength = 40;

        public const int TeamNameMaxLength = 40;

        public const int NationalityMaxLength = 40;

        public const int CoachMaxLength = 40;
    }
}
