﻿namespace Footballers.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server =.; Database=Footballers;User Id = sa; Password=Beatrad1!;MultipleActiveResultSets=true;Trust Server Certificate=true";
    }
}
