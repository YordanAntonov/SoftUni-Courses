﻿namespace Trucks.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=Trucks;User Id=sa;Password=Beatrad1!;MultipleActiveResultSets=true;Trust Server Certificate=true";
    }
}