﻿namespace P02_StudentSystem.Data.Common.Enums
{
    public enum ResourceType
    {
        Video = 0, 
        Presentation = 1,
        Document = 2,
        Other = 3,
    }
}
