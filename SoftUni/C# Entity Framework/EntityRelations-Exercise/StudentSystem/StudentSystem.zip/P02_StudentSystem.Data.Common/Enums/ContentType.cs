﻿namespace P02_StudentSystem.Data.Common.Enums
{
    public enum ContentType
    {
        Application = 0, 
        Pdf = 1, 
        Zip = 2,
    }
}
