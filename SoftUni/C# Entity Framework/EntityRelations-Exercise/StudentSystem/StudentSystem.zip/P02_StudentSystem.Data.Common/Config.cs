﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P02_StudentSystem.Data.Common
{
    public static class Config
    {
        public const string CONNECTION_STRING = @"Server=.;Database=StudentSystem;User Id=sa;Password=Beatrad1!;MultipleActiveResultSets=true;Trust Server Certificate=true";
    }
}
