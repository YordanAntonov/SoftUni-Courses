﻿namespace P02_StudentSystem.Data.Common
{
    public static class Lenghts
    {
        public const int NameMaxSize = 100;

        public const int PhoneNumberMaxSize = 10;

        public const int CourseNameLenght = 80;

        public const int ResourceNameLenght = 50;

        public const int MaxLinkLength = 2088;
    }
}